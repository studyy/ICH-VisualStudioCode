const container = document.querySelector('.container')
console.log(container);
//innerHtml - перезаписывает любое содержимое узла к котому мы обращаемся
container.innerHTML = `
    Hello world
<!--    <h3>hello h3</h3>-->
<h5></h5>
`

const image = document.querySelector('#image')
//первый параметр - имя нужного нам атрибута, второй параметр - значение атрибута (в случае картинки - путь)
image.setAttribute('src', './assets/stanleu.png')
console.log(image);
const input = document.querySelector('#input')
//через value получаем или изменяем значение инпута (value)
input.value = 'hello world'
input.disabled = true
console.log(input.value);

const content = document.querySelector('.content')
//через createElement - создаем элемент на страницу
const title = document.createElement('h3')
const newParagraph = document.createElement('p')
//innerText - задаем текст для элемента
title.innerText = 'New title from JS'
newParagraph.innerText = 'lorem ipsium lorem ipsium lorem ipsium lorem ipsium lorem ipsium'
//append - вкладываем элементы в конец того элемента к котому применяется метод
content.append(title)
content.append(newParagraph)

