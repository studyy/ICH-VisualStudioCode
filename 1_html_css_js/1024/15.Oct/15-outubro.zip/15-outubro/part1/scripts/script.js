// DOM - Document Object Model
// console.log(window);
window.bnpl = 'new obj in global environment'
// console.log([document.body.style]);
const obj = {
    a: 1,
    b: 2,
    acsacsd: 'sdvsd'
}

console.log(obj);
// Работа с подтягиваеним элементов из HTML
// const paragraph = document.getElementById('elem')
const paragraph = document.querySelector('#elem')
const box = document.querySelector('.box')
const strong = document.querySelector('strong')
console.log(paragraph);
console.log(box);
console.log(strong);
const list = document.querySelector(".list")
console.log(list);


const listItem = document.querySelectorAll('.list__item')
const listItem2 = document.getElementsByClassName('list__item')
console.log(listItem);
console.log(listItem2);

function splitList( arr) {
    for(let k of arr) {
        console.log(k)
    }
}

splitList(listItem)
console.log('//////////');
splitList(listItem2)

